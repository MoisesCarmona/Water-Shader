Box_BindPose

contains a rigged box with NO animations




Box_Jump/Walk/Attack/Idle

conatins a rigged box with animations
frame 0 is the BIND POSE
frames 1 - (whatever depending on file) is the actual animation


===========================================================================
Box_BindPose.ma

This file is the box ONLY keyed (has a keyframe) on each bone at frame one.

No actual animation is present.




Box_Idle.ma

Bind pose at frame 0
Animation is NOT baked.
This file has MINIMAL keyframes.



Box_Walk.ma

Bind pose at frame 0
Animation is NOT baked.
This file has MINIMAL keyframes.



Box_Jump.ma

Bind pose at frame 0
Animation IS baked.



Box_Attack.ma

Bind pose at frame 0
Animation is NOT baked.
This file has MINIMAL keyframes.







